package com.alpha.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alpha.dao.StudentDao;
import com.alpha.entity.Student;

@Service
public class StudentService {

	@Autowired
	StudentDao dao;
	public List<Student> getStudentRecord() {
		List<Student> list=dao.getStudentRecord();
		return list;
		//we can write as return dao.getStudentRecord(); and remove 2nd last line 
	}
	
	public String insertStudent(List<Student> al) {
		String msg = dao.insertStudent(al);
		return msg;
	}

	public List<Student> getStudentByID(int roll) {
		return dao.getStudentByID(roll);
	}
	
	
	
}
